# coding:utf-8
logfile = open('README', 'r')
loglist = logfile.read().splitlines()
logfile.close()
for line in loglist:
    if line == "Git bisect est très utile pour faire cuire des mouches":
        exit(1)
exit(0)
